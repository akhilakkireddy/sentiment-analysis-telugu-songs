import os
import codecs
import itertools
import matlab.engine
eng = matlab.engine.start_matlab()
eng.results(nargout=0)
try:
        os.remove("validate.txt")
except OSError:
	pass

fo1 = codecs.open("matlab-output.txt","r")
fo2 = codecs.open("validate.txt","a")
fo3 = codecs.open("testSongs.txt","r")
output,songs = [],[]
for line in fo1:
		output.append(line)
for line in fo3:
		songs.append(line)
for i,j in itertools.izip(songs,output):
		fo2.write(i+"\n")
		fo2.write(j+"\n")
fo1.close()
fo2.close()
fo3.close()
print "check Validate.txt File to cross Validate Results" 
