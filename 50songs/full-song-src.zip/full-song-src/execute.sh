python  make_doc2vec_model.py
python vector.py
python vec2CF.py
python shuffle.py
