cat ./happy/happyOutput > data.txt
cat ./sad/sadOutput >> data.txt
cp data.txt ../

