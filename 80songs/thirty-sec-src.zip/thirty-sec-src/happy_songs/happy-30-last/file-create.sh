a="h_"
c=".txt"
for i in `seq 1 25`;
do

	touch "$a$i$c"
done
